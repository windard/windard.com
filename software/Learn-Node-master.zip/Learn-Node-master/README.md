## This is my node code

### nodo-todo

express 4.x + mysql + bootstrap 的 todo

![nodetodo](images/nodetodo.png)

![nodetodo](images/nodetodo_change.png)

### microblog

这是按照 《node 权威指南》 上的代码进行了修改移植到了 express 4.x 上

![microblog](images/microblog.png)

![microblog](images/microblog_login.png)

![microblog](images/microblog_self.png)

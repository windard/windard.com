function start(){
	console.log("Call 'Start' Handler");
}

function upload(){
	console.log("Call 'Upload' Handler");
}

exports.start = start;
exports.upload = upload;